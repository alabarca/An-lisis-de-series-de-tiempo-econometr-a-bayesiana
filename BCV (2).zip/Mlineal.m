function [N,X,beta,h,sigma,error] = Mlineal(n,B,H)
%Construcci�n modelo de regresi�n lineal
N=n; % Tama�o de la muestra
beta=[0 B]'; %Coeficiente del modelo lineal
data=rand(N,1); %Generaci�n numeros aleatorios distribuidos U(0,1)
X=[ones(N,1) data];
h=H; %error de predicci�n
sigma=1/h; %varianza
error=mvnrnd(zeros(N,1),sigma*eye(N),1)'; %Ruidos
end
