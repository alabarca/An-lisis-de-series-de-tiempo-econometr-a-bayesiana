function [mean_beta_post,sd_beta_post,mean_h_post,sd_h_post,pdata,p,Y,mean_t,sd_t,gl_t,s2_post,V_post,nu_post] = Mpost(N,beta,h,X,error,betaprior,Vprior,s2prior,nuprior)
%Media y varianza param. a posteriori y predicci�n, c�lculo de la dist. a priori y
%verosimilitud dado suposiciones de beta. 
Y=X*beta+error; %Modelo lineal
beta_ols=inv(X'*X)*X'*Y;
nu_prior=nuprior;%par�metro nu de dist. a priori
nu=N-1;
V_prior=Vprior; %par�metro V de dist. a priori
s2_prior=s2prior; %par�metro s de dist. a priori
s2_ols=(Y-X*beta_ols)'*(Y-X*beta_ols)/nu;%Estimaci�n ols de s2
beta_prior=betaprior; %par�metro beta de dist. a priori
V_post=inv(inv(V_prior)+(X'*X));%par�metro V de dist. posterior.
mean_beta_post=V_post*((inv(V_prior)*beta_prior)+((X'*X)*beta_ols));% media del par�metro beta de dist. posterior.
nu_post=nu_prior+N; %par�metro nu de dist. a posteriori
if det(inv(V_prior))>0
s2_post=inv(((nu_prior*inv(s2_prior))+(nu*s2_ols)+((beta_ols-beta_prior)'*inv(V_prior+inv(X'*X))*(beta_ols-beta_prior)))*inv(nu_post));%par�metro s de la dist. posterior
else
s2_post=inv(((nu_prior*inv(s2_prior))+(nu*s2_ols))*inv(nu_post))
end
sd_beta_post=sqrt(nu_post*inv(s2_post)*inv(nu_post-2)*V_post);%desviaci�n est�ndar del par�metro beta de dist. posterior.
mean_h_post=s2_post;%media del par�metro h de dist. posterior.
sd_h_post=2*s2_post*inv(nu_post);%desviaci�n est�ndar del par�metro h de dist. posterior.
c=gamma(nu_post/2)*((nu_prior*inv(s2_prior))^(nu_prior/2))*inv(gamma(nu_prior/2)*(pi^(N/2)));%constante factor de bayes
pdata=c*sqrt(det(V_post)*inv(det(V_prior)))*(nu_post*inv(s2_post))^(-nu_post/2);%verosimilitud
p=mvnpdf(beta,beta_prior,inv(h)*V_prior)*gampdf(h,s2_prior,nu_prior);%funci�n a priori
x_ind=0.5;%individuo
X_pred=[1 x_ind]; %X*
mean_t=X_pred*mean_beta_post;%media distribuci�n X*
sd_t=inv(s2_post)*(1+(X_pred*V_post*X_pred'));%sd distribuci�n X*
gl_t=nu_post;%grados de libertad
end

