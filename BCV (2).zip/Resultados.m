%Ejercicio 8
%Parte a
[N,X,beta,h,sigma,error]=Mlineal(100,1,1);
%Parte b
[mean_beta,sd_beta,mean_h,sd_h,pdata_2,p_2,Y,mean_t,sd_t,gl_t,sd_post,V_post,nu_post]=Mpost(N,beta,h,X,error,[0 1]',eye(2),1,1);
mean_beta;%media beta
sd_beta;%desviaci�n estandar beta
mean_h;%media de h
sd_h;%desviaci�n est�ndar de h
%Parte c
b_2=-3:0.1:3;
cov=inv(sd_post)*V_post;%matriz de covarianza
beta_=(b_2-mean_beta(2))/cov(2,2);
t=(1/cov(2,2))*tpdf(beta_,nu_post);
plot(b_2,t)
%Parte d
[mean_beta1,sd_beta1,mean_h1,sd_h1,pdata_1,p_1,Y1,mean_t1,sd_t1,gl_t1,sd_post1,V_post1,nu_post1]=Mpost(N,[0 0]',h,X,error,[0 1]',eye(2),1,1);
i=1;
BETA=[-1 0.5 1 2 4 6 8];
while i<size(BETA)+1
    [mean_beta2,sd_beta2,mean_h2,sd_h2,pdata_2,p_2,Y,mean_t,sd_t,gl_t,sd_post,V_post,nu_post]=Mpost(N,[0 BETA(i)]',h,X,error,[0 1]',eye(2),1,1);
    PO12(1,i)=pdata_2*p_2*inv(pdata_2*p_2);%Factor de Bayes
    i=i+1;
end    
%Parte e
b_1_pred=-4:0.2:4;
b_2_pred=(b_1_pred-mean_t1)/sd_t1;
t_pred=(1/sd_t1)*tpdf(b_2_pred,gl_t1);
%plot(b_1_pred,t_pred)
%Parte f
i=1;
j=1;
c=[0.01 1 100 1000000];
while j < 8
 while i < 5
    [mean_beta4,sd_beta4,mean_h4,sd_h4,pdata_4,p_4,Y,mean_t,sd_t,gl_t,sd_post,V_post,nu_post]=Mpost(N,[0 BETA(j)]',h,X,error,[0 1]',c(i)*eye(2),1,1);
    mean_beta_V((i^2)-((i-1)^2):(i^2)-((i-1)^2)+1,i,j)=mean_beta4;
    sd_beta_V((i^2)-((i-1)^2):(i^2)-((i-1)^2)+1,:,j)=sd_beta4;
    V_post_((i^2)-((i-1)^2):(i^2)-((i-1)^2)+1,:,j)=V_post;
    h_V(i,:,j)=[mean_h4 sd_h4];
    t_student(i,:,j)=[mean_t sd_t gl_t];
    [mean_beta3,sd_beta3,mean_h3,sd_h3,pdata_3,p_3,Y,mean_t,sd_t,gl_t,sd_post,V_post,nu_post]=Mpost(N,[0 0]',h,X,error,[0 1]',c(i)*eye(2),1,1);
    Bayes_V(i,j)=pdata_3*p_3*inv(pdata_4*p_4);
    i= i + 1;
 end
 j=j+1;
 i=1;
end
par_t=t_student(:,:,3);
b_3_pred1=(b_1_pred-par_t(1,1))/par_t(1,2);
b_3_pred2=(b_1_pred-par_t(2,1))/par_t(2,2);
b_3_pred3=(b_1_pred-par_t(3,1))/par_t(3,2);
b_3_pred4=(b_1_pred-par_t(4,1))/par_t(4,2);
t1=(1/par_t(1,2))*tpdf(b_3_pred1,par_t(1,3));
t2=(1/par_t(2,2))*tpdf(b_3_pred2,par_t(2,3));
t3=(1/par_t(3,2))*tpdf(b_3_pred3,par_t(3,3));
t4=(1/par_t(4,2))*tpdf(b_3_pred4,par_t(4,3));
plot(b_1_pred,t1);
plot(b_1_pred,t2);
plot(b_1_pred,t3);
plot(b_1_pred,t4);
%Parte g
%Usando una a posteriori igual a 1/sigma^2=1
media_beta_ninfo=inv(X'*X)*X'*Y;
sd_beta_ninfo=inv(X'*X);
%Parte f
alpha=0.05;%significancia
I_inf= media_beta_ninfo(2)-norminv(0.01/2,N-1)*sd_beta_ninfo(2,2)/sqrt(N);%cota inferior IC
I_sup=media_beta_ninfo(2)+norminv(0.01/2,N-1)*sd_beta_ninfo(2,2)/sqrt(N);%cota superior IC
IC=[I_inf I_sup];

%Ejercicio 9
%Repetir las instrucciones del ejercicio 8 cambiando los valores para N y
%h.

%Ejercicio 10
beta_prior=[0 1]';
V_prior=eye(2);
h=1;
rep=10000;
MC_mean=mvtrnd((sd_post^2)*V_post,nu_post,rep)+repmat(mean_beta',rep,1);
J_mean=sum(MC_mean/rep);
i=1
H=zeros(2)
while i< rep+1
A=mvtrnd((sd_post^2)*V_post,nu_post,1)-repmat(mean_beta',1,1);
MC_sd=H+A'*A;
i=i+1;
end
J_sd=sqrt(MC_sd/rep);

