library(astsa)
lvrv<-log(varve)
l25<-matrix(0,100,1)
l50<-matrix(0,100,1)
l75<-matrix(0,100,1)
l25[1]<-lvrv[1]
l50[1]<-lvrv[1]
l75[1]<-lvrv[1]
for (i in 2:100)
{
  l25[i]<- (1-0.25)*lvrv[i-1]+0.25*l25[i-1]
  l50[i]<- (1-0.50)*lvrv[i-1]+0.50*l50[i-1]
  l75[i]<- (1-0.75)*lvrv[i-1]+0.75*l75[i-1]
}
plot((1:100),lvrv[1:100],type="l",lty=1,ylab="log varve", xlab="tiempo")
points((1:100),l75[1:100],type="l",lty=2)
points((1:100),l50[1:100],type="l",lty=3)
points((1:100),l25[1:100],type="l",lty=4)
