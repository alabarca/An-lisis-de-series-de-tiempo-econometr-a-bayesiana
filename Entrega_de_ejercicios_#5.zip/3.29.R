library(astsa)
gnp96.dat = read.table("C:/Documents and Settings/Administrador/Escritorio/gnp96.dat", quote="\"")
gnp = ts(gnp96.dat[,2], start=1947, frequency=4)
plot(gnp)
#ARIMA Models
acf(gnp,lag.max=60)
gnpgr = diff(log(gnp)) # tasa de crecimiento
plot.ts(gnpgr)
par(mfrow=c(2,1))
acf(gnpgr, 24)
pacf(gnpgr, 24)
# ARIMA fits:
gnpgr.ar = arima(gnpgr, order = c(1, 0, 0))
#gnpgr.ma = arima(gnpgr, order = c(0, 0, 2))
# to view the results:
gnpgr.ar # potential problem here (see below *)
#gnpgr.ma
#ARMAtoMA(ar=.35, ma=0, 10) # prints psi-weights
dev.off()
tsdiag(gnpgr.ar, gof.lag=20)
hist(gnpgr.ar$resid,br=10)
qqnorm(gnpgr.ar$resid)
shapiro.test(gnpgr.ar$resid)


