library(astsa)
globtemp2<- read.table("C:/Users/alejandro.labarca/Desktop/globtemp2.txt", quote="\"", na.strings="*")
colnames(globtemp2) <- c("Year", "Mean", "5-Year Mean")
Temp=globtemp2
time <- 1880:2004
xt   <- Temp[,2]

plot(time, xt, type="o")

# Evidentemente no es estacionario, por tanto aplicamos la diferencia

dtime <- time[-1]
dxt <- diff(xt)

plot(dtime, dxt, type="o", xlab="Change in Temperature", ylab="Year")

# Veamos la funci�n de autocorrelaci�n y autocorrelaci�n parcial

acf2(dxt);

# Ajuste de varios modelos ARMA seg�n lo anterior

m300 <- arima(dxt, order=c(3,0,0), include.mean=TRUE, method="ML"); print(m300)
tsdiag(m300)

m003<- arima(dxt, order=c(0,0,3), include.mean=TRUE, method="ML"); print(m003)
tsdiag(m003)

m303<- arima(dxt, order=c(3,0,3), include.mean=TRUE, method="ML"); print(m303)
tsdiag(m303)

# AIC dentro de una matriz 
maxp <- maxq <- 6
aic.table <- matrix(NA,nrow=1+maxp, ncol=1+maxq)
rownames(aic.table)<-paste("p",0:maxp,sep="=")     
colnames(aic.table)<-paste("q",0:maxq,sep="=")

for (p in 0:maxp) for (q in 0:maxq) {
  aic.table[1+p,1+q] <- arima(dxt, order=c(p,0,q), include.mean=TRUE, method="ML")$aic
}
pp <- 0:(1+maxp); qq <- 0:(1+maxq)  # one more than nrow or ncol
image(pp,qq,aic.table, col=topo.colors(50))
# Imagen mejorada 
image(pp,qq[-1],aic.table[,-1], col=topo.colors(50))

# MA(4) es el mejor AIC y parece ajustarse bien a los datos  
m004<- arima(dxt, order=c(0,0,4), include.mean=TRUE, method="ML"); print(m004)
tsdiag(m004)



m014 <- arima(xt, order=c(0,1,4), include.mean=TRUE, method="ML"); print(m014); print(m004) 
tsdiag(m014)

n<-length(xt)
show <- 100:n

#Forecast
 
#1era forma
xtt=ts(xt,star=c(1880))
plot(xtt)
sarima.for(xtt,10,0,1,4)

#2da forma

pred <- predict(m014, n.ahead=10)

nf <- length(pred$pred);
lines(2004+1:nf, pred$pred, lty=2, col="red")
lines(2004+1:nf, pred$pred+1.96*pred$se, col="red")
lines(2004+1:nf, pred$pred-1.96*pred$se, col="red")

sarima.for(xtt,10,3,1,0)


