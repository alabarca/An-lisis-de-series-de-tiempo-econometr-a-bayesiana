# Problema 3.37
library(astsa)
ts.plot(unemp) 
attributes(unemp) 
acf2(unemp) 
acf2(diff(unemp,12))
# o diferenciando
acf2(diff(diff(unemp,12)),48) 

#1. SARIMA(2,1,1)x(0,1,1)_12
mod1<-sarima(unemp,2,1,1,0,1,1,12) 
#
#2. SARIMA(1,0,1)x(0,1,1)_12
mod2<-sarima(unemp,1,0,1,0,1,1,12)
mod3<-sarima(unemp,1,0,2,0,1,1,12) 
# 
#3.  SARIMA(2,1,1)x(3,1,0)_12
mod4<-sarima(unemp,2,1,1,3,1,0,12)
#
#4.  SARIMA(1,0,1)x(3,1,0)_12
mod5<-sarima(unemp,1,0,1,3,1,0,12)
mod6<-sarima(unemp,1,0,2,3,1,0,12)
#
r1<-c(mod1$AIC,mod1$AICc,mod1$BIC)
r3<-c(mod3$AIC,mod3$AICc,mod3$BIC)
r4<-c(mod4$AIC,mod4$AICc,mod4$BIC)
r6<-c(mod6$AIC,mod6$AICc,mod6$BIC)


rbind(r1,r3,r4,r6)
#mod6 mejor AIC, mod1 mejor BIC, 
#
par(mfrow=c(2,1))
sarima.for(unemp,12,2,1,1,0,1,1,12)
sarima.for(unemp,12,1,0,2,3,1,0,12)
df<-rbind(sarima.for(unemp,12,2,1,1,0,1,1,12)$pred,sarima.for(unemp,12,1,0,2,3,1,0,12)$pred)
df[1,]-df[2,]
par(mfrow=c(1,1))
plot(1:12,df[1,]-df[2,],xlab="month",ylab="pred_mod1-pred_mod6")







