set.seed(21)
#
x1<-arima.sim(list(order=c(1,0,1),ar=.9,ma=-.9),n=500)# defalt: sigma^2=1
plot(x1)
par(mfrow=c(2,1))
acf(x1)
pacf(x1)
mod1<-arima(x1,order=c(1,0,1),include.mean=FALSE);mod1
#
x2<-arima.sim(list(order=c(1,0,1),ar=.9,ma=-.9),n=500)# defalt: sigma^2=1
plot(x2)
par(mfrow=c(2,1))
acf(x2)
pacf(x2)
mod2<-arima(x2,order=c(1,0,1),include.mean=FALSE);mod2;
#
x3<-arima.sim(list(order=c(1,0,1),ar=.9,ma=-.9),n=500)# defalt: sigma^2=1
par(mfrow=c(2,1))
acf(x3)
pacf(x3)
mod3<-arima(x3,order=c(1,0,1),include.mean=FALSE);mod3
#
rbind(mod1$coef,mod2$coef,mod3$coef)