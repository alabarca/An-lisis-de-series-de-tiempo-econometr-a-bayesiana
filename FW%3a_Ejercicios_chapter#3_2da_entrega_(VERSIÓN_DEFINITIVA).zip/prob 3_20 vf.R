library(astsa)
set.seed(21)
b<-10
est<-c(0.9,0.5,0.25)
for (i in 1:b){
  x<-arima.sim(list(order=c(1,0,1),ar=.9,ma=.5),n=200,sd=sqrt(0.25))# defalt: sigma^2=1
  mod<-arima(x,order=c(1,0,1),include.mean=FALSE,method="ML")
  est<-rbind(est,c(coef(mod),mod$sigma2))
}
est
par(mfrow=c(3,1),font.main=2,font.sub=1,col.axis="blue")
hist(est[2:(b+1),1],xlab="phi",main="AR")
hist(est[2:(b+1),2],xlab="theta",main="MA")
hist(est[2:(b+1),3],xlab="sigma2",main="sigma")
mod
