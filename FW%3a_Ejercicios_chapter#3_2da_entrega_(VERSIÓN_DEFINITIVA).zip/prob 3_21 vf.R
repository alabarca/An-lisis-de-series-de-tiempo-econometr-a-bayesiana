set.seed(21)
num=50
x=arima.sim(list(order=c(1,0,0),ar=.99),n=num)# defalt: sigma^2=1

#bootstrap
m = mean(x) # estimador de la media
fit = ar.yw(x, order=1)
phi = fit$ar # estimador de phi
nboot = 200 # n�mero de iteraciones
resids = fit$resid[-1] # El primer residuo es NA
x.star = x # inicializamos x*
phi.star.yw = rep(NA, nboot)
for (i in 1:nboot) {
 resid.star = sample(resids, replace=TRUE)
 for (t in 1:49){ x.star[t+1] = phi*x.star[t] +
                      resid.star[t]}
 phi.star.yw[i] = ar.yw(x.star, order=1)$ar }
sigma=sqrt((1/num)*(1-(phi^2))) 
u = seq(0.6, 1.1, by=.0001)
pdf(file="pdf.pdf")
hist(phi.star.yw, 10, main="", prob=TRUE, ylim=c(0,21),
    xlim=c(0.6,1.1))
 lines(density(phi.star.yw))
 lines(u, dnorm(u, mean=phi, sd=sigma), lty="dashed", lwd=2)
dev.off()

