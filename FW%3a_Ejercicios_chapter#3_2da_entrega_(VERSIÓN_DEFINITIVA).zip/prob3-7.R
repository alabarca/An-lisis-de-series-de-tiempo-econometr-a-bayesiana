par(mfrow=c(3,1))                         
# in the expressions below, ~ is a space and == is equal
ACF1 = ARMAacf(ar=.6, ma=.9,20) 
plot(ACF1, type="h", xlab="lag")
abline(h=0)
ACF2 = ARMAacf(ar=.6, ma=0, 20)
plot(ACF2, type="h", xlab="lag")
abline(h=0)
ACF3 = ARMAacf(ar=0, ma=.9, 20,pacf=TRUE)
plot(ACF3, type="h", xlab="lag")
abline(h=0)


