# Problem 3.9
set.seed(11)
arma<-arima.sim(list(order=c(1,0,1),ar=.6,ma=.9),n=100)
ar<-arima.sim(list(order=c(1,0,0),ar=.6),n=100)
ma<-arima.sim(list(order=c(0,0,1),ma=.9),n=100)
par(mfrow=c(3,1))
ts.plot(arma)
ts.plot(ar)
ts.plot(ma)
arma_acf<-acf(arma,plot=T)
ar_acf<-acf(ar,plot=T)
ma_acf<-acf(ma,plot=T)
rho<-function(h,phi,theta){
rho<-(1+phi*theta)*(phi+theta)
rho<-phi^(h-1)*rho/(1+2*theta*phi+theta^2)
rho
}
phi<-0.6
theta<-0.9
h<-1;rho(h,phi,theta)
xx<-1:10
yy1<-matrix(0,10,1)
yy2<-matrix(0,10,1)
yy3<-matrix(0,1,1)
for (i in 1:10){
yy1[i]<-rho(i,phi,theta)
yy2[i]<-rho(i,phi,theta=0)
yy3[i]<-rho(i,phi=0,theta)}
# compare  theoretical acf  and esimated  in simulations
par(mfrow=c(1,1))
plot(c(1,10),c(1,-0.2),type="n",xlab="lag",ylab="rho",main="ACF")
lines(xx,yy1,lty=1) #ARMA
points(xx,yy1,pch=1)
points(xx,arma_acf$acf[2:11],pch=1)
lines(xx,arma_acf$acf[2:11],lty=1)
lines(xx,yy2,lty=2)#AR
points(xx,yy2,pch=3)
points(xx,ar_acf$acf[2:11],pch=3)
lines(xx,ar_acf$acf[2:11],lty=2)
lines(xx,yy3,lty=3)#MA
points(xx,yy3,pch=2)
points(xx,ma_acf$acf[2:11],pch=2)
lines(xx,ma_acf$acf[2:11],lty=3)
abline(h=0)
abline(h=2/sqrt(100),lty=2)
abline(h=-2/sqrt(100),lty=2)
#
# compare acf and pacf in simulated series
par(mfrow=c(2,1))
acf(ar)
pacf(ar)
par(mfrow=c(2,1))
acf(ma)
pacf(ma)
par(mfrow=c(2,1))
acf(arma)
pacf(arma)

