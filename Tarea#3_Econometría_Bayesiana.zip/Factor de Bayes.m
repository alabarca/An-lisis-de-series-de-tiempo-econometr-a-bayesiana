%---Estimador de Bayes priori conjugada (bondad de ajuste)
j=1;
c=gamma(v_post/2)*((v_prior*inv(S_prior))^(v_prior/2))*inv(gamma(v_prior/2)*(pi^(dim(1)/2)));%constante factor de bayes
while j<101
    pdata(j)=c*sqrt(det(V_post)*inv(det(V_prior)))*(v_post*inv(S_post(j)))^(-v_post/2);%verosimilitud
    p(j,:)=mvnpdf(beta_OLS,beta_prior(j),SIGMA_OLS*V_prior)*gampdf(inv(SIGMA_OLS),S_prior,v_prior);%funci�n a priori
    j=j+1; 
end
j=1;
while j<101
    BAYES(j)=pdata(51)*p(51)*inv(pdata(j)*p(j));
    j=j+1;
end
