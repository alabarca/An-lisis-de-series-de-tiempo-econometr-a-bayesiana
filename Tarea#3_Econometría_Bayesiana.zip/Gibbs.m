%------Algoritmo de Gibbs-----
Z=X
a_prior=beta_prior(51)
a_post=beta_post(51)
K=dim(1)
T=14
M=K
n=14*14
forecasting=0
repfor = 10;
p=1
% Gibbs-related preliminaries
nsave = 2000;         % Final number of draws to save
nburn = 200;         % Draws to discard (burn-in)
ntot = nsave + nburn;  % Total number of draws
it_print = 2000;      % Print on the screen every "it_print"-th iteration
h = 1;               % Number of forecast periods

impulses = 1;        % 1: compute impulse responses, 0: no impulse responses
ihor = 21;           % Horizon to compute impulse responses

tic;
disp('Number of iterations');
for irep = 1:ntot  %Start the Gibbs "loop"
    if mod(irep,it_print) == 0
        disp(irep);
        toc;
    end
    
    VARIANCE = kron(inv(SIGMA_OLS),speye(dim(1)));
    V_post = inv(inv(V_prior) + Z'*VARIANCE*Z);
    a_post = V_post*(inv(V_prior)*a_prior + Z'*VARIANCE*Y(:));
    alpha = a_post + chol(V_post)'*randn(n,1); % Draw of alpha
    
    ALPHA = reshape(alpha,K,M); % Draw of ALPHA
    
    % Posterior of SIGMA|ALPHA,Data ~ iW(inv(S_post),v_post)
    v_post = dim(1) + v_prior;
    S_post = S_prior + (Y - X*ALPHA)'*(Y - X*ALPHA);
    SIGMA = inv(wish(inv(S_post),v_post));% Draw SIGMA

    % Store results  
    if irep > nburn               
        %=========FORECASTING:
        if forecasting==1
            if forecast_method == 0   % Direct forecasts
                Y_temp = zeros(repfor,M);
                % compute 'repfor' predictions for each draw of ALPHA and SIGMA
                for ii = 1:repfor
                    X_fore = [1 Y(T,:) X(T,2:M*(p-1)+1)];
                    % Forecast of T+1 conditional on data at time T
                    Y_temp(ii,:) = X_fore*ALPHA + randn(1,M)*chol(SIGMA);
                end
                % Matrix of predictions
                Y_pred(((irep-nburn)-1)*repfor+1:(irep-nburn)*repfor,:) = Y_temp;
                % Predictive likelihood
                PL(irep-nburn,:) = mvnpdf(Y1(T+1,:),X(T,:)*ALPHA,SIGMA);
                if PL(irep-nburn,:) == 0
                    PL(irep-nburn,:) = 1;
                end
            elseif forecast_method == 1   % Iterated forecasts
                % The usual way is to write the VAR(p) model in companion
                % form, i.e. as VAR(1) model in order to estimate the
                % h-step ahead forecasts directly (this is similar to the 
                % code we use below to obtain impulse responses). Here we 
                % just iterate over h periods, obtaining the forecasts at 
                % T+1, T+2, ..., T+h iteratively.
                
                for ii = 1:repfor
                    % Forecast of T+1 conditional on data at time T
                    X_fore = [1 Y(T,:) X(T,2:M*(p-1)+1)];
                    Y_hat = X_fore*ALPHA + randn(1,M)*chol(SIGMA);
                    Y_temp = Y_hat;
                    X_new_temp = X_fore;
                    for i = 1:h-1  % Predict T+2, T+3 until T+h                   
                        if i <= p
                            % Create matrix of dependent variables for                       
                            % predictions. Dependent on the horizon, use the previous                       
                            % forecasts to create the new right-hand side variables
                            % which is used to evaluate the next forecast.                       
                            X_new_temp = [1 Y_hat X_fore(:,2:M*(p-i)+1)];
                            % This gives the forecast T+i for i=1,..,p                       
                            Y_temp = X_new_temp*ALPHA + randn(1,M)*chol(SIGMA);                       
                            Y_hat = [Y_hat Y_temp];
                        else
                            X_new_temp = [1 Y_hat(:,1:M*p)];
                            Y_temp = X_new_temp*ALPHA + randn(1,M)*chol(SIGMA);
                            Y_hat = [Y_hat Y_temp];
                        end
                    end %  the last value of 'Y_temp' is the prediction T+h
                    Y_temp2(ii,:) = Y_temp;
                end
                % Matrix of predictions               
                Y_pred(((irep-nburn)-1)*repfor+1:(irep-nburn)*repfor,:) = Y_temp2;
                % Predictive likelihood
                PL(irep-nburn,:) = mvnpdf(Y1(T+h,:),X_new_temp*ALPHA,SIGMA);
                if PL(irep-nburn,:) == 0
                    PL(irep-nburn,:) = 1;
                end
            end
        end % end forecasting
        %=========Forecasting ends here
        
        %=========IMPULSE RESPONSES:
        if impulses==1
            biga = zeros(M*p,M*p);
            for j = 1:p-1
                biga(j*M+1:M*(j+1),M*(j-1)+1:j*M) = eye(M);
            end
            
            atemp = ALPHA(2:end,:);
            atemp = atemp(:);
            splace = 0;
            for ii = 1:p
                for iii = 1:M
                    biga(iii,(ii-1)*M+1:ii*M) = atemp(splace+1:splace+M,1)';
                    splace = splace + M;
                end                
            end
            
            % St dev matrix for structural VAR
            STCO = chol(SIGMA);
            
            % Now get impulse responses for 1 through nhor future periods
            impresp = zeros(M,M*ihor);
            impresp(1:M,1:M) = STCO;
            bigai = biga;
            for j = 1:ihor-1
                impresp(:,j*M+1:(j+1)*M) = bigj*bigai*bigj'*STCO;
                bigai = bigai*biga;
            end
            
            % Get the responses of all M variables to a shock imposed on
            % the 'equatN'- th equation:
            equatN = M; %this assumes that the interest rate is sorted last in Y
            impf_m = zeros(M,ihor);
            jj=0;
            for ij = 1:ihor
                jj = jj + equatN;
                impf_m(:,ij) = impresp(:,jj);
            end
            imp(irep-nburn,:,:) = impf_m;
                
        end
               
        %----- Save draws of the parameters
        alpha_draws(irep-nburn,:) = alpha;
        ALPHA_draws(irep-nburn,:,:) = ALPHA;
        SIGMA_draws(irep-nburn,:,:) = SIGMA;

    end % end saving results
       
end %end the main Gibbs for loop
%====================== End Sampling Posteriors ===========================

%Posterior mean of parameters:
ALPHA_mean = squeeze(mean(ALPHA_draws,1)); %posterior mean of ALPHA
SIGMA_mean = squeeze(mean(SIGMA_draws,1)); %posterior mean of SIGMA

% mean prediction and log predictive likelihood
if forecasting == 1
    Y_pred_mean = mean(Y_pred,1);
    log_PL = mean((log(PL)),1);

%This are the true value of Y at T+h:
if forecast_method == 0
    true_value = Y1(T+1,:);
elseif forecast_method == 1
    true_value = Y1(T+h,:);
end
%(subsequently you can easily also get MSFE and MAFE)
    
end


% You can also get other quantities, like impulse responses
if impulses==1;
    qus = [.1, .5, .90];
    imp_resp = squeeze(quantile(imp,qus));
end

clc;
toc;

