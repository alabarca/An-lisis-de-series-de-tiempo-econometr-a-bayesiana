%----Hiperpar�metros a Priori para modelo lineal
% Definici�n de Hiperpar�metros
K=1;
M=1;
i=0.5;
j=0;
prior=1;
while prior < 3
    while i < 0.8
        if prior == 1 % Noninformtive
            % I guess there is nothing to specify in this case!
            % Posteriors depend on OLS quantities
        elseif prior == 2 % Normal-Wishart (nat conj)
            % Hyperparameters on a ~ N(a_prior, SIGMA x V_prior)
            A_prior = i*ones(K,M);
            beta_prior(j+1) = A_prior(:);
            V_prior = SIGMA_OLS*eye(1);
            % Hyperparameters on inv(SIGMA) ~ W(v_prior,inv(S_prior))
            v_prior = M;
            S_prior = eye(M);
            inv_S_prior = inv(S_prior);
        end
        j=j+1;
        i=i+0.003;
    end
    prior=prior+1;
    i=0.5;
    j=0;
end
    
%============================ POSTERIOR ==================================
%==========================================================================
    
%--------- Hiperpar�metros a posteriori de ALPHA y SIGMA con Priori Difusa
prior=1;
i=0.5;
j=1;
while prior < 3
    while i < 0.8
        if prior == 1
            % Posterior of alpha|Data ~ Multi-T(kron(SSE,inv(X'X)),alpha_OLS,T-K)
            V_post_noinfo = inv(X'*X);
            beta_post_noinfo= beta_OLS;
                        
            % posterior of SIGMA|Data ~ inv-Wishart(SSE,T-K)
            S_post_noinfo = SSE;
            v_post_noinfo= dim(1)-1;
            
            % Now get the mean and variance of the Multi-t marginal posterior of alpha
            alpha_mean_noinfo = beta_post_noinfo;
            alpha_var_noinfo = (1/(v_post_noinfo - M - 1))*kron(S_post_noinfo,V_post_noinfo);
            
            %--------- Posterior hyperparameters of ALPHA and SIGMA with Normal-Wishart Prior
        elseif prior == 2
            % ******Get all the required quantities for the posteriors
            % For alpha
            V_post = inv( inv(V_prior) + X'*X );
            A_post= V_post * ( inv(V_prior)*beta_prior(j) + X'*X*beta_OLS );
            beta_post(:,j) = A_post(:);
            
            % For SIGMA
            S_post(j) = SSE + S_prior + beta_OLS'*X'*X*beta_OLS + beta_prior(j)'*inv(V_prior)*beta_prior(j) - beta_post(:,j)'*( inv(V_prior) + X'*X )*beta_post(:,j);
            v_post = dim(1) + v_prior;
            
            % Now get the mean and variance of the Multi-t marginal posterior of alpha
            alpha_mean(:,j) = beta_post(:,j);
            alpha_var(:,:,j) = (1/(v_post - M - 1))*kron(S_post(j),V_post);
        end
        i=i+0.003;
        j=j+1;
    end
    prior=prior+1;
    i=0.5;
    j=1;
end

c=gamma(nu_post/2)*((nu_prior*inv(s2_prior))^(nu_prior/2))*inv(gamma(nu_prior/2)*(pi^(N/2)));%constante factor de bayes
pdata=c*sqrt(det(V_post)*inv(det(V_prior)))*(nu_post*inv(s2_post))^(-nu_post/2);%verosimilitud
p=mvnpdf(beta,beta_prior,inv(h)*V_prior)*gampdf(h,s2_prior,nu_prior);%funci�n a priori
