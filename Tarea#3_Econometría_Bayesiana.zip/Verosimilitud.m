%----M�xima verosimilitud----
load data.txt;
dim=size(data);
X=[data(1:dim(1),1),data(1:dim(1),2)]; %matriz variables explicativas
Y=data(1:dim(1),3); %variable dependiente
beta_OLS = inv(X'*X)*(X'*Y); %coeficientes estimados
SSE = (Y - X*beta_OLS)'*(Y - X*beta_OLS); %error cuadr�tico medio
SIGMA_OLS = SSE./(dim(1)-2); % estimador sigma_2
Y1=X*beta_OLS+(mvnrnd(0,SIGMA_OLS,14));%construcci�n modelo

%bondad de ajuste
fitlm(X(:,2),Y)

