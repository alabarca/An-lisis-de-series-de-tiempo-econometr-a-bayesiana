
library(astsa) #package series de tiempo

PIB_USA<-read.delim("C:/Users/alabarca/Desktop/PIB TRIMESTRAL USA 1947_2015.txt") #lectura de la data

par(mfrow=c(3,1)) #ventana m�ltiple al graficar. Espec�ficamente 3 gr�ficos

#Poducto interno bruto trimestral USA 1947-2013
PIB_USA.=ts(PIB_USA[,2],frequency=4,start=c(1947,1)) #serie de tiempo del producto interno bruto de USA.

plot(PIB_USA.) # gr�fico de la serie de tiempo anterior

acf(PIB_USA.) # funci�n de autocorrelaci�n de la serie


log_PIB_USA.=ts(log(as.numeric(PIB_USA[,2])),frequency=4,start=c(1947,1))# serie de tiempo del logaritmo neperiano de PIB_USA.

plot(log_PIB_USA.) #gr�fico de la serie de tiempo anterior

acf(log_PIB_USA.) # funci�n de autocorrelaci�n de la serie


diff_PIB_USA.=ts(-log(as.numeric(PIB_USA[4:273,2]))+log(as.numeric(PIB_USA[5:273,2])),frequency=4,start=c(1947,4)) #serie de los incrementos logar�tmicos de PIB.USA. respecto al �ltimo trimestre

plot(diff_PIB_USA.) #gr�fico de la serie de tiempo anterior

acf(diff_PIB_USA.)# funci�n de autocorrelaci�n de la serie

#Poducto interno bruto VEN 1960-2014

PIB_VEN<- read.delim("C:/Users/alabarca/Desktop/PIN_VEN 1960_2013.txt", header=FALSE)

par(mfrow=c(3,1))

PIB_VEN.=ts(PIB_VEN[,2],start=c(1960,1)) #serie de tiempo del producto interno bruto de VEN.

plot(PIB_VEN.) #gr�fico de la serie de tiempo anterior

acf(PIB_VEN.)

log_PIB_VEN.=ts(log(as.numeric(PIB_VEN[,2])),start=c(1960,1))  # serie de tiempo del logaritmo neperiano de PIB_VEN.

plot(log_PIB_VEN.) #gr�fico de la serie de tiempo anterior

acf(log_PIB_VEN.)#funci�n de autocorrelaci�n

diff_PIB_VEN.=ts(log(as.numeric(PIB_VEN[2:54,2]))-log(as.numeric(PIB_VEN[,2])),start=c(1960,1))#serie de los incrementos logar�tmicos de PIB.VEN. anuales

plot(diff_PIB_VEN.) #gr�fico de la serie de tiempo anterior

acf(diff_PIB_VEN.) #funci�n de autocorrelaci�n de la serie


